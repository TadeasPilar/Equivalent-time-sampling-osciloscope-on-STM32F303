Equivalent sampling scope on development board NUCLEO-F303RE
Tade� Pila�   pilartad@fel.cvut.cz
Czech Technical University in Prague
Faculty of Electrical Engeneering
Department of Measurment
--------------------------------------------------------------------------------
System requirements:           
Windows 7 or newer. 32bit or 64bit.
NUCLEO-F303RE development board.
USB A to Mini USB cable.
Two wires for the required connections(see step 3 below).

--------------------------------------------------------------------------------
Getting started:

1. Unzip this file. No instalation required.

2. Install ST-LINK drivers, unless already installed.   
   Drivers for both 32bit and 64bit Windows can be found
   in the "ST-Link_driver_WINDOWS" folder.
   
3. Prepare your NUCLEO-F303RE. Connect pin PA0 to pin PA7 and PA12 to PA15.

4. Connect NUCLEO to your computer. Removable drive "NODE_F303RE" should
   appear in your file manager.
   
5. Coppy "SamplingScope.bin" to "NODE_F303RE". Wait for the file
   to disappear from the drive. LED in top-right corner of NUCLEO board
   should start blinking green and red. 
   
6. Run "SamplingScope.exe".

7. Click Connect->Connect. Select on "Nucleo-F303RE" from the list.
   If you dont see this option, go back step 2. Click on Connect. 
   The Connect button should light up green. You can now close this window.
   
8. You should be now able to use the osciloscope if you connect any
   periodic signal to CH1(A0). Try connecting signal from buildin
   generator on PB8 to check if everything is working.  
   
--------------------------------------------------------------------------------
Pinout:
Channel 1 - PA0 and A0
Channel 2 - PC4
Channel 3 - PB1   
Channel 4 - PB12
Signal generator - PB8 and D15

   
   
   
   
   
   
   
   
   
   